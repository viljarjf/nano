#pragma once

void testStdLists();
