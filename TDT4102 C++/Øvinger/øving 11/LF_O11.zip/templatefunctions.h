#pragma once

void testTemplateFunctions();
